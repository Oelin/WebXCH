const express = require('express');
const app = express();
const http = require('http');
const server = http.createServer(app);
const { Server } = require("socket.io");
const ss = require('socket.io-stream');
const io = new Server(server);


function randomId() {
  return `${Math.floor(Math.random() * Date.now())}`.slice(5)
}


const peers = {
}


app.get('/', (req, res) => {

  if (! req.headers.cookie) {
    console.log('setting cookie')
    res.cookie('randomID', randomId())
  }
  res.sendFile(__dirname + '/index.html');
});


app.get('/socket.io-stream.js', (req, res) => {
  res.sendFile(__dirname + '/socket.io-stream.js')
})


io.on('connection', (socket) => {

  console.log('a user connected');
  let selfId

  socket.on('join room', ({ id }) => {
    peers[id] = socket
    selfId = id
    console.log('added user ' + id + ' to room')
    console.log('relaying to all users...')

    io.emit('room members', { peers: Object.keys(peers) })
  })

  socket.on('disconnect', function() {
    console.log('removing ' + selfId + ' from peers')
    delete peers[selfId]

    io.emit('room members', { peers: Object.keys(peers) })
  })

  ss(socket).on('transfer-send', function(stream, { filename, length, id }) {

    console.log('got transfer send request')
    console.log(filename)
    const recStreamSocket = ss(peers[id])
    const newStream = ss.createStream()

    recStreamSocket.emit('transfer-rec', newStream, { filename, length })
    stream.pipe(newStream)
  })
});

server.listen(3000, () => {
  console.log('listening on *:3000');
});
